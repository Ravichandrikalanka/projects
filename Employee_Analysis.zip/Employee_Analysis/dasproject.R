#library(tidyverse)
#employee_data <- read_rds(url("C:\Users\RAVI CHANDRIKA\Downloads\employee_data.rds"))
#employee_data <- read_rds(url("C:/Users/RAVI CHANDRIKA/Downloads/employee_data.rds"))
library(tidyverse)
employee_data <- read_rds("C:/Users/RAVI CHANDRIKA/Downloads/employee_data.rds")



# ... with 1,460 more rows, and 7 more variables: yrs_at_company <int>,
#   yrs_since_promotion <int>, previous_companies <dbl>,
#   job_satisfaction <fct>, performance_rating <fct>, marital_status <fct>,
#   miles_from_home <int>

employee_data %>% group_by(left_company) %>% 
  summarise(n_employees = n(),
            min_salary = min(salary),
            avg_salary = mean(salary),
            max_salary = max(salary),
            sd_salary = sd(salary),
            pct_less_60k = mean(salary <= 60000))



# ... with 1 more variable: pct_less_60k <dbl>


ggplot(data = employee_data, aes(x = salary, fill = left_company)) + 
  geom_histogram(aes(y = ..density..), color = "white", bins = 20) +
  facet_wrap(~ left_company, nrow = 2) +
  labs(title = "Employee Salary Distribution by Status (Left the Comapny - Yes/No)",
       x = "Salary (US Dollars", y = "Proportion of Employees")

Q1 <- employee_data %>% group_by(left_company,job_level)%>% select(left_company,job_level) %>% summarise(total = n())
Q1                      


### Data Visulatization




Q2 <- employee_data %>% group_by(left_company) %>% 
  summarise(n_employees = n(),
            min_weekly_hours = min(weekly_hours),
            avg_weekly_hours = mean(weekly_hours),
            max_weekly_hours = max(weekly_hours),
            sd_weekly_hours = sd(weekly_hours)) 
Q2




# ... with 1 more variable: sd_weekly_hours <dbl>
### Data Visulatization

ggplot(data = employee_data, aes(x=weekly_hours, fill = left_company))+
  geom_histogram(color = "blue", bins = 30)+
  facet_wrap(~ left_company, nrow = 2) +
  labs(title = "Employee Weekly Hours Distribution by Weekly Hours (Left the Comapny - Yes/No)",
       x = "Weekly Hours", y = "Proportion of Employees")

#sd_weekly_hours = sd(weekly_hours)

Q3 <- employee_data %>% group_by(left_company,department)%>% select(left_company,department, miles_from_home) %>% summarise( quantile1_miles_from_home = quantile(miles_from_home, 1 / 4), mean_miles_from_home = mean(miles_from_home), quantile3_miles_from_home = quantile(miles_from_home, 3 / 4)) %>% arrange(department,desc(left_company)) 
Q3

ggplot(data = employee_data, aes(x=miles_from_home, fill = left_company))+
  geom_boxplot(aes (y =  department),color = "blue", bins = 30) +
  labs(title = "Employee's Distance To Company Distribution Divide By Department(Left the Comapny - Yes/No)",
       x = "Distance", y = "Department")+
  theme(plot.title = element_text(size=9))



Q4 <- employee_data %>% group_by(left_company,marital_status)%>% select(left_company,marital_status,salary) %>% 
  summarise( quantile1_salarye = quantile(salary, 1 / 4),
             mean_salary = mean(salary),
             quantile3_salary = quantile(salary, 3 / 4)) %>%
  arrange(marital_status,desc(left_company))

ggplot(data = employee_data, aes(x=salary, fill = left_company))+
  geom_boxplot(aes (y =  marital_status),color = "blue", bins = 30) +
  labs(title = "Employee's Salary To Company Distribution Divide By Marital_Status(Left the Comapny - Yes/No)",
       x = "Distence", y = "Department")+
  theme(plot.title = element_text(size=9))



Q5 <- employee_data %>% group_by(left_company, department)%>% select(department,salary) %>% 
  summarise( quantile1_salarye = quantile(salary, 1 / 4),
             mean_salary = mean(salary),
             quantile3_salary = quantile(salary, 3 / 4)) %>%
  arrange(department,desc(left_company))

ggplot(data = employee_data, aes(x= department, color = left_company))+
  geom_point(position=position_jitterdodge(),alpha=.6,aes (y =  salary), bins = 30) +
  labs(title = "Employee's Salary To Company Distribution Divide By Years in Company(Left the Comapny - Yes/No)",
       x = "Department", y = "Salary")+
  theme(plot.title = element_text(size=9),
        axis.text.x = element_text(size=6) )

ggplot(data = employee_data, aes(x= job_satisfaction, color = left_company))+
  geom_point(position=position_jitterdodge(),alpha=.6,aes (y =  salary), bins = 30) +
  labs(title = "Employee's Salary To Company Distribution Divide By Years in Company(Left the Comapny - Yes/No)",
       x = "Department", y = "Salary")+
  theme(plot.title = element_text(size=9),
        axis.text.x = element_text(size=6) )


ggplot(data = employee_data, aes(x= yrs_at_company, color = left_company))+
  geom_point(position=position_jitterdodge(),alpha=.6,aes (y =  salary), bins = 30) +
  labs(title = "Employee's Salary To Company Distribution Divide By Years in Company(Left the Comapny - Yes/No)",
       x = "Years at company", y = "Salary")+
  theme(plot.title = element_text(size=9),
        axis.text.x = element_text(size=6) )


employee_data_Sales <- employee_data %>% filter(employee_data$department == 'Sales')

ggplot(data = employee_data_Sales, aes(x= yrs_at_company, color = left_company))+
  geom_point(position=position_jitterdodge(),alpha=.6,aes (y =  salary), bins = 30) +
  labs(title = "Sales's Salary To Company Distribution Divide By Years in Company(Left the Comapny - Yes/No)",
       x = "Years at company", y = "Salary")+
  theme(plot.title = element_text(size=9),
        axis.text.x = element_text(size=6) )


employee_data_Researchs <- employee_data %>% filter(employee_data$department == 'Research')

ggplot(data = employee_data_Researchs, aes(x= yrs_at_company, color = left_company))+
  geom_point(position=position_jitterdodge(),alpha=.6,aes (y =  salary), bins = 30) +
  labs(title = "Research's Salary To Company Distribution Divide By Years in Company(Left the Comapny - Yes/No)",
       x = "Years at company", y = "Salary")+
  theme(plot.title = element_text(size=9),
        axis.text.x = element_text(size=6) )


employee_data_Marketing <- employee_data %>% filter(employee_data$department == 'Marketing')

ggplot(data = employee_data_Marketing, aes(x= yrs_at_company, color = left_company))+
  geom_point(position=position_jitterdodge(),alpha=.6,aes (y =  salary), bins = 30) +
  labs(title = "Marketing's Salary To Company Distribution Divide By Years in Company(Left the Comapny - Yes/No)",
       x = "Years at company", y = "Salary")+
  theme(plot.title = element_text(size=9),
        axis.text.x = element_text(size=6) )


employee_data_Product_Development <- employee_data %>% filter(employee_data$department == 'Product Development')

ggplot(data = employee_data_Product_Development, aes(x= yrs_at_company, color = left_company))+
  geom_point(position=position_jitterdodge(),alpha=.6,aes (y =  salary), bins = 30) +
  labs(title = "Product Development's Salary To Company Distribution Divide By Years in Company(Left the Comapny - Yes/No)",
       x = "Years at company", y = "Salary")+
  theme(plot.title = element_text(size=9),
        axis.text.x = element_text(size=6) )


employee_data_IT_and_Analytics <- employee_data %>% filter(employee_data$department == 'IT and Analytics')

ggplot(data = employee_data_IT_and_Analytics, aes(x= yrs_at_company, color = left_company))+
  geom_point(position=position_jitterdodge(),alpha=.6,aes (y =  salary), bins = 30) +
  labs(title = "IT and Analytics' Salary To Company Distribution Divide By Years in Company(Left the Comapny - Yes/No)",
       x = "Years at company", y = "Salary")+
  theme(plot.title = element_text(size=9),
        axis.text.x = element_text(size=6) )


employee_data_Finance_and_Operations <- employee_data %>% filter(employee_data$department == 'Finance and Operations')

ggplot(data = employee_data_Finance_and_Operations, aes(x= yrs_at_company, color = left_company))+
  geom_point(position=position_jitterdodge(),alpha=.6,aes (y =  salary), bins = 30) +
  labs(title = "Finance_and_Operations' Salary To Company Distribution Divide By Years in Company(Left the Comapny - Yes/No)",
       x = "Years at company", y = "Salary")+
  theme(plot.title = element_text(size=9),
        axis.text.x = element_text(size=6) )

