import pandas as pd
import streamlit as st
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import LabelEncoder, StandardScaler
from sklearn.neighbors import KNeighborsClassifier
from sklearn.metrics import accuracy_score, confusion_matrix

# Title
st.title("🌾 Smart Crop and Fertilizer Recommendation System (KNN Classifier)")

# Load Dataset
@st.cache_data
def load_data():
    data = pd.read_csv(r"C:\Users\RAVI CHANDRIKA\Desktop\newml\Farm_Recommendation.csv")
    return data

data = load_data()

# Encode categorical features
soil_encoder = LabelEncoder()
region_encoder = LabelEncoder()
fertilizer_encoder = LabelEncoder()
crop_encoder = LabelEncoder()

data['soil_type_encoded'] = soil_encoder.fit_transform(data['soil_type'])
data['region_encoded'] = region_encoder.fit_transform(data['region'])
data['fertilizer_encoded'] = fertilizer_encoder.fit_transform(data['recommended_fertilizer'])
data['crop_encoded'] = crop_encoder.fit_transform(data['recommended_crop'])

# Sidebar Inputs
st.sidebar.title("🧑‍🌾 Farmer Input Parameters")

soil_input = st.sidebar.selectbox("Soil Type", data['soil_type'].unique())
region_input = st.sidebar.selectbox("Region", data['region'].unique())
temperature_input = st.sidebar.slider("Temperature (°C)", float(data['temperature'].min()), float(data['temperature'].max()), float(data['temperature'].mean()))
water_input = st.sidebar.selectbox("Water Available", ['Yes', 'No'])

# Encode user input
soil_encoded = soil_encoder.transform([soil_input])[0]
region_encoded = region_encoder.transform([region_input])[0]
water_encoded = 1 if water_input == 'Yes' else 0

# Feature & Target Preparation
features = ['soil_type_encoded', 'region_encoded', 'temperature', 'water_available']
data['water_available'] = data['water_available'].map({'Yes': 1, 'No': 0})
X = data[features]
y_crop = data['crop_encoded']
y_fertilizer = data['fertilizer_encoded']

# Train-test split
X_train, X_test, y_crop_train, y_crop_test = train_test_split(X, y_crop, test_size=0.2, random_state=42)
_, _, y_fert_train, y_fert_test = train_test_split(X, y_fertilizer, test_size=0.2, random_state=42)

# Scaling
scaler = StandardScaler()
X_train_scaled = scaler.fit_transform(X_train)
X_test_scaled = scaler.transform(X_test)
user_input_scaled = scaler.transform([[soil_encoded, region_encoded, temperature_input, water_encoded]])

# Crop Model
crop_model = KNeighborsClassifier(n_neighbors=5)
crop_model.fit(X_train_scaled, y_crop_train)
crop_pred = crop_encoder.inverse_transform(crop_model.predict(user_input_scaled))[0]

# Fertilizer Model
fertilizer_model = KNeighborsClassifier(n_neighbors=5)
fertilizer_model.fit(X_train_scaled, y_fert_train)
fertilizer_pred = fertilizer_encoder.inverse_transform(fertilizer_model.predict(user_input_scaled))[0]

# Output
st.success(f"🌱 Recommended Crop: **{crop_pred}**")
st.success(f"🧪 Recommended Fertilizer: **{fertilizer_pred}**")

# Accuracy and Heatmap
if st.checkbox("Show Model Accuracy"):
    crop_accuracy = accuracy_score(y_crop_test, crop_model.predict(X_test_scaled))
    fert_accuracy = accuracy_score(y_fert_test, fertilizer_model.predict(X_test_scaled))

    st.metric("Crop Recommendation Accuracy", f"{crop_accuracy:.2%}")
    st.metric("Fertilizer Recommendation Accuracy", f"{fert_accuracy:.2%}")

    if st.checkbox("Show Confusion Matrix Heatmaps"):
        # Crop Confusion Matrix
        crop_cm = confusion_matrix(y_crop_test, crop_model.predict(X_test_scaled), labels=crop_model.classes_)
        plt.figure(figsize=(10, 6))
        sns.heatmap(crop_cm, annot=True, fmt='d', cmap='YlGnBu',
                    xticklabels=crop_encoder.inverse_transform(crop_model.classes_),
                    yticklabels=crop_encoder.inverse_transform(crop_model.classes_))
        plt.title("🌾 Crop Prediction Confusion Matrix")
        plt.xlabel("Predicted")
        plt.ylabel("Actual")
        st.pyplot(plt)

        # Fertilizer Confusion Matrix
        fert_cm = confusion_matrix(y_fert_test, fertilizer_model.predict(X_test_scaled), labels=fertilizer_model.classes_)
        plt.figure(figsize=(10, 6))
        sns.heatmap(fert_cm, annot=True, fmt='d', cmap='YlOrBr',
                    xticklabels=fertilizer_encoder.inverse_transform(fertilizer_model.classes_),
                    yticklabels=fertilizer_encoder.inverse_transform(fertilizer_model.classes_))
        plt.title("🧪 Fertilizer Prediction Confusion Matrix")
        plt.xlabel("Predicted")
        plt.ylabel("Actual")
        st.pyplot(plt)

# Dataset Preview
if st.checkbox("Show Raw Dataset"):
    st.write(data)
