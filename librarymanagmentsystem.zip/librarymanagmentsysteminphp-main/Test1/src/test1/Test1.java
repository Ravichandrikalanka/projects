import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;
public class Test1
{
    public static void main (String args[])
    {
        try{
            Class.forName("com.mysql.jdbc.Driver");
            Connection con=DriverManager.getConnection("jdbc:mysql://localhost:/test123","root","" );
            if(con!=null)
            {
                System.out.println("data connected sucseccfully");
                
            }
            else
                System.out.println("unable to connect database");
        }
        catch(SQLException e)
        {
            System.out.println(e);
        }
    }
}