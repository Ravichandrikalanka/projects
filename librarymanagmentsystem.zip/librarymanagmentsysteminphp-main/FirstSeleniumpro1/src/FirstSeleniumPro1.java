import org.openqa.selenium.WebDriver;
import org.openqa.selenium.edge.EdgeDriver;

public class FirstSeleniumPro1 {
    public static void main(String[] args) {
        // Set the path to the EdgeDriver executable
        System.setProperty("webdriver.edge.driver", "D:\\DEVOPS LAB\\WebDrivers\\msedgedriver.exe");

        // Initialize the EdgeDriver
        WebDriver driver = new EdgeDriver();

        try {
            // Open the local HTML file
            driver.get("file:///D:/DEVOPS%20LAB/EventRegistrationForm.html");

            // Print the title of the page
            System.out.println("Title: " + driver.getTitle());

            // Wait for 60 seconds to allow observation
            Thread.sleep(60000);
        } catch (Exception e) {
            System.out.println("Error: " + e.getMessage());
        } finally {
            // Close the browser
            driver.quit();
        }
    }
}
