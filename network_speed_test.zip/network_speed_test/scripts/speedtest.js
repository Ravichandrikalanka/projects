document.getElementById('testBtn').addEventListener('click', function () {
    testSpeed();
});

function testSpeed() {
    // Fetch data from the Fast.com API
    fetch('https://api.fast.com/netflix/speedtest')
        .then(response => response.json())  // Parse the JSON response
        .then(data => {
            // Make sure data is correctly received
            console.log(data);  // You can check the full response in the browser console
            
            // Check if the required properties are present in the response
            if (data.downloadSpeed && data.uploadSpeed && data.latency) {
                const downloadSpeed = (data.downloadSpeed / 1e6).toFixed(2); // Convert to Mbps
                const uploadSpeed = (data.uploadSpeed / 1e6).toFixed(2);   // Convert to Mbps
                const ping = data.latency;

                // Update the UI with the results
                document.getElementById('downloadSpeed').textContent = downloadSpeed;
                document.getElementById('uploadSpeed').textContent = uploadSpeed;
                document.getElementById('ping').textContent = ping;

                // Update the chart with the results
                updateChart(downloadSpeed, uploadSpeed, ping);
            } else {
                alert("Error: Unable to retrieve speed data. Please try again later.");
            }
        })
        .catch(error => {
            console.error("Error fetching speed data:", error);
            alert("An error occurred while fetching speed data. Please try again later.");
        });
}

// Function to update the chart with the new speed data
let speedChart;
function updateChart(downloadSpeed, uploadSpeed, ping) {
    const ctx = document.getElementById('speedChart').getContext('2d');

    if (!speedChart) {
        // Create the chart if it doesn't exist
        speedChart = new Chart(ctx, {
            type: 'bar',
            data: {
                labels: ['Download', 'Upload', 'Ping'],
                datasets: [{
                    label: 'Speed (Mbps)',
                    data: [downloadSpeed, uploadSpeed, ping],
                    backgroundColor: ['#4CAF50', '#FF9800', '#F44336'],
                    borderColor: ['#388E3C', '#FF5722', '#D32F2F'],
                    borderWidth: 1
                }]
            },
            options: {
                scales: {
                    y: {
                        beginAtZero: true
                    }
                }
            }
        });
    } else {
        // Update the existing chart with new data
        speedChart.data.datasets[0].data = [downloadSpeed, uploadSpeed, ping];
        speedChart.update();
    }
}
