// Function to test download speed
async function testDownloadSpeed() {
    const startTime = Date.now();
    const response = await fetch('https://www.gstatic.com/og/_/js/k=og.qtm.en_US.oO7MeNjrwf4.O/d/ft=browser/rt=j/sv=1/js/ah=7ECeF69f3tV5DbiLfXY7dsrquV0E5m4xgZ69BQYSZgkA7f2fvmJAczt_gBEPJMyqra3hoK7pOsY8y0kEYQoQgZGAxWc7AEXbscsfLuf7lFY3JXozPZmDBkcA1kjsCkZX0hKzc2fg==');
    const data = await response.text();
    const endTime = Date.now();
    
    const duration = (endTime - startTime) / 1000; // Time in seconds
    const fileSize = data.length / 1024 / 1024; // Size in Megabytes
    const speed = (fileSize / duration).toFixed(2); // Speed in Mbps

    return speed;
}

// Function to test upload speed
async function testUploadSpeed() {
    const startTime = Date.now();
    const data = new Array(1024).join('a'); // 1KB of data
    const response = await fetch('https://httpbin.org/post', {
        method: 'POST',
        body: data,
    });
    const endTime = Date.now();

    const duration = (endTime - startTime) / 1000; // Time in seconds
    const speed = ((data.length / 1024 / 1024) / duration).toFixed(2); // Speed in Mbps

    return speed;
}

// Start test
document.getElementById('startTest').addEventListener('click', async () => {
    document.getElementById('download').textContent = 'Testing...';
    document.getElementById('upload').textContent = 'Testing...';

    const downloadSpeed = await testDownloadSpeed();
    const uploadSpeed = await testUploadSpeed();

    document.getElementById('download').textContent = downloadSpeed;
    document.getElementById('upload').textContent = uploadSpeed;
});
