pip install speedtest
import speedtest
import csv
import os
from datetime import datetime

# Directory to save results
RESULTS_DIR = "results"
RESULTS_FILE = os.path.join(RESULTS_DIR, "speed_test_results.csv")

# Ensure the results directory exists
os.makedirs(RESULTS_DIR, exist_ok=True)

# Function to test internet speed
def test_speed():
    print("Testing internet speed...")
    st = speedtest.Speedtest()
    st.get_best_server()
    
    download_speed = st.download() / 1_000_000  # Convert to Mbps
    upload_speed = st.upload() / 1_000_000  # Convert to Mbps
    ping = st.results.ping
    
    return download_speed, upload_speed, ping

# Function to save results to a CSV file
def save_results(download, upload, ping):
    # Check if the file exists, create with header if not
    file_exists = os.path.isfile(RESULTS_FILE)
    with open(RESULTS_FILE, mode='a', newline='') as file:
        writer = csv.writer(file)
        if not file_exists:
            writer.writerow(["Timestamp", "Download Speed (Mbps)", "Upload Speed (Mbps)", "Ping (ms)"])
        
        # Write the test results
        timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        writer.writerow([timestamp, download, upload, ping])
    print(f"Results saved to {RESULTS_FILE}")

# Main function
def main():
    download, upload, ping = test_speed()
    print(f"Download Speed: {download:.2f} Mbps")
    print(f"Upload Speed: {upload:.2f} Mbps")
    print(f"Ping: {ping:.2f} ms")
    
    save_results(download, upload, ping)

if __name__ == "__main__":
    main()
