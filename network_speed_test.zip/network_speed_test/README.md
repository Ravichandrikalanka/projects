# Network Speed Test Dashboard

This project is a web-based dashboard that allows users to test their internet speed (download, upload, and ping) and display the results using a chart.

## Files and Structure

- **index.html**: The main HTML page displaying the user interface.
- **styles/style.css**: The CSS for styling the page.
- **scripts/speedtest.js**: JavaScript for handling the speed test and updating the dashboard.
- **assets/logo.png**: Placeholder logo for the project.

## How to Run

1. Clone or download this repository.
2. Open `index.html` in a browser.
3. Click the **Test Speed** button to perform the speed test.

### Libraries Used
- [Chart.js](https://www.chartjs.org/) for displaying speed data in a bar chart.
- [Fast.com Speedtest API](https://fast.com) for fetching speed data.

